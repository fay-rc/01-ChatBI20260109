
import React, { useState, useRef } from 'react';
import { FileData, SheetData, FieldCategorization, DataRow } from '../types';

declare const XLSX: any;
declare const Papa: any;

interface FileUploaderProps {
  onDataLoaded: (data: FileData[]) => void;
}

const FileUploader: React.FC<FileUploaderProps> = ({ onDataLoaded }) => {
  const [files, setFiles] = useState<File[]>([]);
  const [loading, setLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const categorizeFields = (rows: DataRow[], columns: string[]): FieldCategorization => {
    const cats: FieldCategorization = {
      'ID Fields': [],
      'Content Fields': [],
      'Category Fields': [],
      'Time Fields': [],
      'Numeric Fields': [],
      'Other Fields': []
    };

    const idPatterns = /id|uuid|code|no|序号|主键|编号/i;
    const timePatterns = /time|date|year|month|day|时间|日期|年份/i;

    columns.forEach(col => {
      const sampleValues = rows.slice(0, 50).map(r => r[col]).filter(v => v !== undefined && v !== null);
      if (sampleValues.length === 0) {
        cats['Other Fields'].push(col);
        return;
      }

      const firstVal = sampleValues[0];
      const name = col.toLowerCase();

      // 1. ID Check
      if (idPatterns.test(name)) {
        cats['ID Fields'].push(col);
        return;
      }

      // 2. Time Check
      const isDate = firstVal instanceof Date || (typeof firstVal === 'string' && !isNaN(Date.parse(firstVal)) && (firstVal.includes('-') || firstVal.includes('/')) || timePatterns.test(name));
      if (isDate) {
        cats['Time Fields'].push(col);
        return;
      }

      // 3. Numeric Check
      const isNumeric = typeof firstVal === 'number' || (!isNaN(Number(firstVal)) && typeof firstVal !== 'boolean');
      if (isNumeric) {
        cats['Numeric Fields'].push(col);
        return;
      }

      // 4. Content vs Category Check for Strings
      if (typeof firstVal === 'string') {
        const uniqueValues = new Set(rows.map(r => r[col]));
        const cardinality = uniqueValues.size / rows.length;
        
        if (firstVal.length > 50 || cardinality > 0.8) {
          cats['Content Fields'].push(col);
        } else if (uniqueValues.size < 20 || cardinality < 0.2) {
          cats['Category Fields'].push(col);
        } else {
          cats['Other Fields'].push(col);
        }
        return;
      }

      cats['Other Fields'].push(col);
    });

    return cats;
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const newFiles = Array.from(e.target.files);
      setFiles(prev => [...prev, ...newFiles]);
    }
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const removeFile = (index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
  };

  const processSingleFile = (file: File): Promise<FileData> => {
    return new Promise((resolve) => {
      const reader = new FileReader();
      if (file.name.endsWith('.csv')) {
        reader.onload = (e) => {
          const text = e.target?.result as string;
          Papa.parse(text, {
            header: true,
            dynamicTyping: true,
            complete: (results: any) => {
              const columns = results.meta.fields || [];
              const rows = results.data;
              const sheet: SheetData = {
                name: 'Default',
                rows,
                columns,
                fieldCategorization: categorizeFields(rows, columns)
              };
              resolve({
                name: file.name,
                sheets: [sheet],
                activeSheetIndex: 0
              });
            }
          });
        };
        reader.readAsText(file);
      } else {
        reader.onload = (e) => {
          const data = new Uint8Array(e.target?.result as ArrayBuffer);
          const workbook = XLSX.read(data, { type: 'array' });
          const sheets: SheetData[] = workbook.SheetNames.map((name: string) => {
            const worksheet = workbook.Sheets[name];
            const rows = XLSX.utils.sheet_to_json(worksheet) as DataRow[];
            const columns = rows.length > 0 ? Object.keys(rows[0]) : [];
            return {
              name,
              rows,
              columns,
              fieldCategorization: categorizeFields(rows, columns)
            };
          });
          resolve({
            name: file.name,
            sheets,
            activeSheetIndex: 0
          });
        };
        reader.readAsArrayBuffer(file);
      }
    });
  };

  const processFiles = async () => {
    if (files.length === 0) return;
    setLoading(true);
    try {
      const allData: FileData[] = [];
      for (const file of files) {
        const data = await processSingleFile(file);
        allData.push(data);
      }
      onDataLoaded(allData);
    } catch (err) {
      console.error("Error processing files:", err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center w-full max-w-3xl mx-auto p-4">
      <input type="file" ref={fileInputRef} className="hidden" multiple accept=".csv, .xlsx, .xls" onChange={handleFileChange} />
      <div className="w-full min-h-[200px] flex flex-wrap gap-4 items-center justify-center">
        {files.length === 0 ? (
          <div className="w-full h-64 border-2 border-dashed border-slate-300 rounded-2xl flex flex-col items-center justify-center cursor-pointer hover:border-blue-400 hover:bg-slate-50 transition-all shadow-sm" onClick={() => fileInputRef.current?.click()}>
            <div className="p-4 bg-slate-50 rounded-full mb-4">
              <svg className="w-10 h-10 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" /></svg>
            </div>
            <p className="text-slate-600 font-medium text-lg mb-1">请上传您的文件</p>
            <p className="text-slate-400 text-sm">支持 CSV, Excel (XLSX, XLS) 格式</p>
          </div>
        ) : (
          <div className="flex flex-wrap gap-4 items-center justify-center w-full">
            {files.map((file, index) => (
              <div key={`${file.name}-${index}`} className="group relative w-40 h-44 bg-white border border-slate-200 rounded-xl shadow-sm p-4 flex flex-col items-center justify-center animate-in zoom-in duration-200">
                <div className="p-3 bg-blue-50 rounded-lg mb-3">
                  <svg className="w-8 h-8 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                </div>
                <span className="text-slate-700 font-medium text-xs text-center line-clamp-2 px-1 break-all w-full">{file.name}</span>
                <span className="text-slate-400 text-[10px] mt-1">{(file.size / 1024).toFixed(1)} KB</span>
                <button onClick={() => removeFile(index)} className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 hover:bg-red-600 shadow-md transition-colors">
                  <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
                </button>
              </div>
            ))}
            <button onClick={() => fileInputRef.current?.click()} className="w-40 h-44 border-2 border-dashed border-blue-200 rounded-xl flex flex-col items-center justify-center text-blue-400 hover:border-blue-400 hover:text-blue-500 hover:bg-blue-50/50 transition-all duration-200 group">
              <div className="p-3 bg-white rounded-full shadow-sm border border-blue-50 mb-2 group-hover:scale-110 transition-transform">
                <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v16m8-8H4" /></svg>
              </div>
              <span className="text-sm font-medium">继续添加</span>
            </button>
          </div>
        )}
      </div>
      <button onClick={processFiles} disabled={files.length === 0 || loading} className={`mt-10 px-16 py-3.5 rounded-full font-bold text-lg transition-all transform active:scale-95 ${files.length > 0 && !loading ? 'bg-blue-600 text-white hover:bg-blue-700 shadow-lg shadow-blue-200' : 'bg-slate-200 text-slate-400 cursor-not-allowed'}`}>
        {loading ? <div className="flex items-center"><svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>处理中...</div> : '确定'}
      </button>
    </div>
  );
};

export default FileUploader;
