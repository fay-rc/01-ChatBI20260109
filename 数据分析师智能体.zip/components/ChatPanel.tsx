
import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI, GenerateContentResponse, Type } from "@google/genai";
import { SheetData } from '../types';

interface AnalysisStep {
  title: string;
  description: string;
  isConfirmed?: boolean;
}

interface Message {
  role: 'user' | 'assistant';
  content: string;
  type?: 'text' | 'strategy';
  steps?: AnalysisStep[];
}

interface ChatPanelProps {
  activeSheets: SheetData[];
  onTriggerAnalysis: (customSteps?: string[]) => Promise<void>;
  hasAnalysis: boolean;
}

const ChatPanel: React.FC<ChatPanelProps> = ({ activeSheets, onTriggerAnalysis, hasAnalysis }) => {
  const [messages, setMessages] = useState<Message[]>([
    { role: 'assistant', content: '您好！数据已准备就绪。您可以直接向我提问，或者点击“AI自动分析思路”。针对您的每一个问题，我都会先为您梳理分析思路，确认后再执行深度计算。', type: 'text' }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  
  // 追踪正在编辑的步骤坐标：消息索引和步骤索引
  const [editingPos, setEditingPos] = useState<{ msgIdx: number; stepIdx: number } | null>(null);
  const [editValue, setEditValue] = useState('');
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const stopRef = useRef<boolean>(false);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  /**
   * 核心逻辑：无论是点击按钮还是输入问题，都调用此函数生成思路大纲
   */
  const generateStrategy = async (userQuery?: string) => {
    if (isTyping || activeSheets.length === 0) return;

    setIsTyping(true);
    stopRef.current = false;
    
    // 如果是对话框输入的，先添加用户消息
    if (userQuery) {
      setMessages(prev => [...prev, { role: 'user', content: userQuery, type: 'text' }]);
    } else {
      setMessages(prev => [...prev, { role: 'user', content: "请为我生成AI自动分析思路大纲", type: 'text' }]);
    }

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const columns = activeSheets.flatMap(s => s.columns);
      const contextDescription = activeSheets.map(s => `表名: ${s.name}, 列: ${s.columns.join(', ')}`).join('\n');
      
      const prompt = `
        基于以下数据上下文：
        ${contextDescription}
        
        用户当前的需求/问题是：${userQuery || "进行全面深度的数据分析"}
        
        请针对该需求，生成一个专业且详尽的数据分析思路大纲。
        要求：
        1. 必须包含恰好 8 个分析步骤（Step）。
        2. 每个步骤包含一个简短的标题 (title)。
        3. 每个步骤包含一段详细的描述 (description)，字数在50字左右，需明确：本步计划对什么具体数据（字段）进行操作、实行什么样的分析方法（如聚合、趋势、关联、预测等）、最终预期产出什么样的洞察或可视化结论。
        4. 请以 JSON 数组形式返回对象，每个对象含 title 和 description。
      `;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.ARRAY,
            items: { 
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                description: { type: Type.STRING }
              },
              required: ["title", "description"]
            }
          }
        }
      });

      if (stopRef.current) return;

      let steps: AnalysisStep[] = JSON.parse(response.text || "[]").slice(0, 8);
      // 补全逻辑
      while(steps.length < 8) {
        steps.push({
          title: `补充维度 ${steps.length + 1}`,
          description: "计划对现有数值字段进行深入的分布扫描，通过统计学描述分析其稳定性，产出数据质量与波动范围报告。"
        });
      }
      
      setMessages(prev => [...prev, { 
        role: 'assistant', 
        content: userQuery 
          ? `针对您的提问：“${userQuery}”，我规划了以下 8 个分析步骤。您可以根据实际需求微调描述或删除步骤，确认后我将开始为您生成分析报告。`
          : '这是为您深度定制的 8 个分析步骤。每个步骤都包含了具体的数据操作思路。确认大纲后我将按此执行。', 
        type: 'strategy',
        steps: steps
      }]);
    } catch (error) {
      console.error('Strategy error:', error);
      setMessages(prev => [...prev, { role: 'assistant', content: '抱歉，规划分析思路时出现了异常，请重试。', type: 'text' }]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleSendMessage = () => {
    if (!inputValue.trim() || isTyping || activeSheets.length === 0) return;
    const query = inputValue;
    setInputValue('');
    generateStrategy(query);
  };

  const handleEditStep = (msgIdx: number, stepIdx: number) => {
    const step = messages[msgIdx].steps?.[stepIdx];
    if (step) {
      setEditingPos({ msgIdx, stepIdx });
      setEditValue(step.description);
    }
  };

  const saveEdit = () => {
    if (!editingPos) return;
    const { msgIdx, stepIdx } = editingPos;
    
    setMessages(prev => {
      const next = [...prev];
      if (next[msgIdx].steps) {
        const nextSteps = [...next[msgIdx].steps!];
        nextSteps[stepIdx] = { ...nextSteps[stepIdx], description: editValue };
        next[msgIdx].steps = nextSteps;
      }
      return next;
    });
    setEditingPos(null);
  };

  const deleteStep = (msgIdx: number, stepIdx: number) => {
    setMessages(prev => {
      const next = [...prev];
      if (next[msgIdx].steps) {
        next[msgIdx].steps = next[msgIdx].steps!.filter((_, i) => i !== stepIdx);
      }
      return next;
    });
  };

  const confirmAnalysis = (msgIdx: number) => {
    const strategyMessage = messages[msgIdx];
    if (!strategyMessage.steps || strategyMessage.steps.length === 0) return;

    // 标记为已确认
    setMessages(prev => {
      const next = [...prev];
      if (next[msgIdx].steps) {
        next[msgIdx].steps = next[msgIdx].steps!.map(s => ({ ...s, isConfirmed: true }));
      }
      // 添加一条确认消息
      next.push({ role: 'user', content: '确认大纲，开始执行分析。', type: 'text' });
      return next;
    });

    // 触发报告生成
    const combinedSteps = strategyMessage.steps.map(s => `${s.title}: ${s.description}`);
    onTriggerAnalysis(combinedSteps);
  };

  const stopGeneration = () => {
    stopRef.current = true;
    setIsTyping(false);
  };

  return (
    <div className="flex flex-col h-full overflow-hidden bg-white">
      <div className="p-4 border-b border-slate-100 flex items-center justify-between">
        <h4 className="text-xs font-black text-slate-800 flex items-center gap-2">
          <span className={`w-2 h-2 rounded-full ${isTyping ? 'bg-emerald-500 animate-pulse' : 'bg-slate-300'}`}></span>
          AI 助手分析中
        </h4>
      </div>

      <div className="flex-grow overflow-y-auto p-4 space-y-4 scrollbar-hide">
        {messages.map((msg, msgIdx) => (
          <div key={msgIdx} className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
            <div className={`max-w-[90%] px-4 py-3 rounded-2xl text-sm leading-relaxed ${msg.role === 'user' ? 'bg-blue-600 text-white rounded-tr-none shadow-md shadow-blue-100' : 'bg-slate-50 text-slate-700 border border-slate-100 rounded-tl-none whitespace-pre-wrap'}`}>
              {msg.content}
            </div>
            
            {msg.type === 'strategy' && msg.steps && msg.steps.length > 0 && (
              <div className="mt-4 w-full grid grid-cols-1 gap-3 animate-in fade-in slide-in-from-top-4 duration-500">
                {msg.steps.map((step, sIdx) => (
                  <div key={sIdx} className="flex flex-col bg-white border border-slate-200 p-4 rounded-xl hover:shadow-md transition-all group relative">
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className={`flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-black ${step.isConfirmed ? 'bg-emerald-100 text-emerald-600' : 'bg-blue-100 text-blue-600'}`}>
                          {sIdx + 1}
                        </div>
                        <h5 className="text-xs font-black text-slate-800">{step.title}</h5>
                      </div>
                      {!step.isConfirmed && (
                        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <button onClick={() => handleEditStep(msgIdx, sIdx)} className="p-1 hover:bg-slate-100 rounded text-slate-400 hover:text-blue-500" title="编辑描述">
                            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" /></svg>
                          </button>
                          <button onClick={() => deleteStep(msgIdx, sIdx)} className="p-1 hover:bg-red-50 rounded text-slate-400 hover:text-red-500" title="删除步骤">
                            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
                          </button>
                        </div>
                      )}
                    </div>

                    {editingPos?.msgIdx === msgIdx && editingPos?.stepIdx === sIdx ? (
                      <div className="space-y-2">
                        <textarea 
                          autoFocus
                          value={editValue} 
                          onChange={(e) => setEditValue(e.target.value)}
                          className="w-full text-xs border border-blue-200 rounded-lg p-2 outline-none focus:ring-1 focus:ring-blue-500 min-h-[80px]"
                        />
                        <div className="flex justify-end gap-2">
                          <button onClick={() => setEditingPos(null)} className="text-[10px] text-slate-400 font-bold px-2 py-1">取消</button>
                          <button onClick={saveEdit} className="bg-blue-500 text-white text-[10px] font-bold px-3 py-1 rounded-lg">保存修改</button>
                        </div>
                      </div>
                    ) : (
                      <p className="text-[11px] text-slate-500 leading-relaxed italic">
                        {step.description}
                      </p>
                    )}
                  </div>
                ))}
                {!msg.steps[0]?.isConfirmed && (
                  <div className="pt-2 sticky bottom-0 bg-white/80 backdrop-blur-sm pb-2 z-10">
                    <button 
                      onClick={() => confirmAnalysis(msgIdx)}
                      className="w-full py-3 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-xl text-xs font-black shadow-lg shadow-blue-200 hover:scale-[1.01] active:scale-95 transition-all"
                    >
                      确认大纲，开始执行深度分析
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        ))}
        {isTyping && messages[messages.length-1]?.role === 'user' && (
          <div className="flex justify-start">
            <div className="bg-slate-50 px-4 py-3 rounded-2xl rounded-tl-none text-slate-400 text-sm animate-pulse">正在为您构建深度分析路径...</div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="p-4 bg-slate-50 border-t border-slate-100">
        <div className="relative bg-white rounded-2xl border border-slate-200 shadow-sm focus-within:ring-2 focus-within:ring-blue-500 transition-all p-1">
          <div className="flex px-2 pt-1 mb-1">
            <button 
              onClick={() => generateStrategy()}
              disabled={isTyping || activeSheets.length === 0}
              className="flex items-center gap-1.5 px-3 py-1 bg-blue-50 text-blue-600 rounded-lg text-[10px] font-black hover:bg-blue-100 transition-colors border border-blue-100 disabled:opacity-50 disabled:cursor-not-allowed group"
            >
              <svg className="w-3 h-3 group-hover:rotate-12 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
              </svg>
              AI自动分析思路
            </button>
          </div>

          <div className="relative">
            <input 
              type="text" 
              value={inputValue} 
              onChange={(e) => setInputValue(e.target.value)} 
              onKeyDown={(e) => e.key === 'Enter' && !isTyping && handleSendMessage()} 
              placeholder={activeSheets.length === 0 ? "请先勾选数据表..." : "输入问题，AI将先为您生成分析大纲"} 
              disabled={activeSheets.length === 0} 
              className="w-full bg-transparent border-none py-3 px-4 pr-12 text-sm outline-none disabled:opacity-50"
            />
            {isTyping ? (
              <button 
                onClick={stopGeneration} 
                className="absolute right-2 top-1.5 p-1.5 rounded-xl transition-all text-red-600 bg-red-50 hover:bg-red-100 shadow-sm animate-in zoom-in duration-200"
                title="终止生成"
              >
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8 7a1 1 0 00-1 1v4a1 1 0 001 1h4a1 1 0 001-1V8a1 1 0 00-1-1H8z" clipRule="evenodd" />
                </svg>
              </button>
            ) : (
              <button 
                onClick={handleSendMessage} 
                disabled={!inputValue.trim() || activeSheets.length === 0}
                className={`absolute right-2 top-1.5 p-1.5 rounded-xl transition-all ${inputValue.trim() ? 'text-blue-600 bg-blue-50' : 'text-slate-300'}`}
              >
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z" />
                </svg>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatPanel;
