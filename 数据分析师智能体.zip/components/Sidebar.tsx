
import React from 'react';
import { FileData } from '../types';

interface SidebarProps {
  fileDatas: FileData[];
  selectedSheets: Map<number, Set<number>>;
  onToggleSheet: (fileIdx: number, sheetIdx: number) => void;
  onToggleFile: (fileIdx: number) => void;
  isVisible: boolean;
  onToggleVisibility: () => void;
  width: number;
}

const Sidebar: React.FC<SidebarProps> = ({ 
  fileDatas, 
  selectedSheets, 
  onToggleSheet, 
  onToggleFile,
  isVisible,
  onToggleVisibility,
  width
}) => {
  if (!isVisible) return null;

  return (
    <div 
      style={{ width: `${width}px` }}
      className="h-full bg-white border-r border-slate-200 flex flex-col overflow-hidden flex-shrink-0 animate-in slide-in-from-left duration-300"
    >
      <div className="p-4 border-b border-slate-100 bg-slate-50/50 flex items-center justify-between sticky top-0 z-10 backdrop-blur-sm">
        <h3 className="text-sm font-black text-slate-700 uppercase tracking-tight flex items-center gap-2">
          数据展示
        </h3>
        <button 
          onClick={onToggleVisibility}
          className="p-1.5 hover:bg-slate-200 rounded-lg transition-colors text-slate-400 hover:text-slate-600"
          title="隐藏面板"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M11 19l-7-7 7-7m8 14l-7-7 7-7" />
          </svg>
        </button>
      </div>

      <div className="flex-grow overflow-y-auto p-4 space-y-6 scrollbar-hide">
        {fileDatas.map((file, fIdx) => {
          const fileSelectedCount = selectedSheets.get(fIdx)?.size || 0;
          const isFileFullySelected = fileSelectedCount === file.sheets.length;
          
          return (
            <div key={fIdx} className="space-y-4">
              <div className="flex items-center gap-2 text-slate-900 font-bold truncate text-sm px-1">
                <input 
                  type="checkbox" 
                  checked={isFileFullySelected}
                  onChange={() => onToggleFile(fIdx)}
                  className="w-4 h-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500 cursor-pointer"
                />
                <div className="bg-blue-100 p-1 rounded-md">
                  <svg className="w-3.5 h-3.5 text-blue-600 shrink-0" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4z" />
                  </svg>
                </div>
                <span className="truncate" title={file.name}>{file.name}</span>
              </div>

              <div className="space-y-3">
                {file.sheets.map((sheet, sIdx) => {
                  const isSelected = selectedSheets.get(fIdx)?.has(sIdx);
                  return (
                    <div key={sIdx} className="space-y-3 group/sheet">
                      <label className={`flex items-center gap-3 cursor-pointer p-3 rounded-xl transition-all border ${isSelected ? 'bg-blue-50 border-blue-100 shadow-sm' : 'hover:bg-slate-50 border-transparent hover:border-slate-100'}`}>
                        <input 
                          type="checkbox" 
                          checked={isSelected}
                          onChange={() => onToggleSheet(fIdx, sIdx)}
                          className="peer w-4 h-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500 cursor-pointer"
                        />
                        <div className="flex flex-col overflow-hidden">
                          <span className={`text-xs font-bold transition-colors truncate ${isSelected ? 'text-blue-700' : 'text-slate-600'}`}>
                            {sheet.name}
                          </span>
                          <span className="text-[10px] text-slate-400 font-medium">
                            {sheet.rows.length} 条记录
                          </span>
                        </div>
                      </label>

                      {/* 竖向显示字段列表 */}
                      {isSelected && (
                        <div className="ml-8 space-y-1.5 border-l-2 border-blue-100 pl-4 py-1 animate-in slide-in-from-top-2 duration-300">
                          <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-2">包含字段 ({sheet.columns.length})</p>
                          {sheet.columns.map((col, cIdx) => (
                            <div key={cIdx} className="flex items-center gap-2 group/field">
                              <div className="w-1.5 h-1.5 rounded-full bg-blue-300 group-hover/field:bg-blue-500 transition-colors"></div>
                              <span className="text-xs text-slate-500 group-hover/field:text-slate-700 truncate font-medium">
                                {col}
                              </span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
      
      <div className="p-4 bg-slate-50 border-t border-slate-100">
      </div>
    </div>
  );
};

export default Sidebar;
