
import { GoogleGenAI, Type } from "@google/genai";
import { StepResult } from "../types";

export const analyzeSingleStep = async (
  title: string, 
  description: string, 
  dataSample: any[], 
  columns: string[]
): Promise<StepResult> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const prompt = `
    你是一个专业的数据分析师。
    当前分析步骤标题: ${title}
    分析任务描述: ${description}
    
    数据上下文：
    列名: ${columns.join(", ")}
    数据样例: ${JSON.stringify(dataSample)}

    任务要求：
    请根据描述执行深度分析，并生成以下三部分内容：
    1. 针对本步骤的专业总结（summary）。
    2. 发现的 3-5 条核心业务洞察（insights）。
    3. 建议的 1-2 个可视化图表（charts），包括类型（bar, line, pie, scatter）、标题、X轴和Y轴字段。

    输出必须严格按照 JSON 格式。
  `;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          summary: { type: Type.STRING },
          insights: {
            type: Type.ARRAY,
            items: { type: Type.STRING }
          },
          charts: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                type: { type: Type.STRING, description: "bar, line, pie, or scatter" },
                title: { type: Type.STRING },
                xAxis: { type: Type.STRING },
                yAxis: { type: Type.STRING }
              },
              required: ["type", "title", "xAxis", "yAxis"]
            }
          }
        },
        required: ["summary", "insights", "charts"]
      }
    }
  });

  return JSON.parse(response.text || "{}") as StepResult;
};

// 保留原有函数以兼容其他可能的调用
export const analyzeData = async (dataSample: any[], columns: string[], customSteps?: string[]): Promise<any> => {
  // 原有逻辑可根据需要保留或重构，此处为了满足新需求，建议主逻辑迁移至 analyzeSingleStep
  return analyzeSingleStep("全量分析", "对数据集进行综合深度解析", dataSample, columns);
};
